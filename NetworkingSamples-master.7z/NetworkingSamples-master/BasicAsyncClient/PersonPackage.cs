﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Net;
using System.Text;

namespace BasicAsyncClient
{
    class PersonPackage
    {
        public bool IsMale { get; set; }
        public ushort Age { get; set; }
        public string Name { get; set; }
        public IPEndPoint EndPoint { get; set; }

        public PersonPackage(bool male, ushort age, string name, string end)
        {
            IsMale = male;
            Age = age;
            Name = name;
            EndPoint = new IPEndPoint(IPAddress.Parse(end), 3333);




        }

        /// <summary>
        /// Deserialize data received.
        /// </summary>
        public PersonPackage(byte[] data)
        {
            IsMale = BitConverter.ToBoolean(data, 0);
            Age = BitConverter.ToUInt16(data, 1);
            int nameLength = BitConverter.ToInt32(data, 3);
            int name = BitConverter.ToInt32(data, 10);
            Name = Encoding.ASCII.GetString(data, 7, nameLength);
            string a = EndPoint.ToString();
            //byteList.AddRange(BitConverter.GetBytes(a.Length));
            //byteList.AddRange(Encoding.ASCII.GetBytes(a));
            ////  EndPoint = Encoding.Default.GetAddressBytes(data);
            //EndPoint = BitConverter.ToInt64(data,EndPoint[4]);
            // EndPoint = Encoding.Default.GetString(data,4,name);
            // EndPoint = encod
        }

        /// <summary>
        ///  Serializes this package to a byte array.
        /// </summary>
        /// <remarks>
        /// Use the <see cref="Buffer"/> or <see cref="Array"/> class for better performance.
        /// </remarks>
        public byte[]   ToByteArray()
        {
            List<byte> byteList = new List<byte>();
            byteList.AddRange(BitConverter.GetBytes(IsMale));
            byteList.AddRange(BitConverter.GetBytes(Age));
            byteList.AddRange(BitConverter.GetBytes(Name.Length));
            byteList.AddRange(Encoding.ASCII.GetBytes(Name));

            string a = EndPoint.ToString();
            IPEndPoint ipa = CreateIPEndPoint(a);
            //ipa.ToString();
            //byteList.AddRange(BitConverter.GetBytes(ipa.Length));
            byteList.AddRange(Encoding.ASCII.GetBytes(ipa.ToString()));
            
            IPEndPoint CreateIPEndPoint(string l)
            {
                string[] ep = l.Split('.');
                // if (ep.Length != 1) throw new FormatException("Invalid endpoint format");
                IPAddress ip;
                if (!IPAddress.TryParse(ep[0], out ip))
                {
                    throw new FormatException("Invalid ip-adress");
                }
                //int port;
                //if (!int.TryParse(ep[4], NumberStyles.None, NumberFormatInfo.CurrentInfo, out port))
                //{
                //    throw new FormatException("Invalid port");
                //}
                return new IPEndPoint(ip, 0);





                //byteList.AddRange(BitConverter.GetBytes(EndPoint.AddressFamily.GetTypeCode(EndPoint)));
                //   byteList.AddRange(Encoding.ASCII.GetType.EndPoint(EndPoint));

                ////  Byte[] bytes = EndPoint.GetAddressBytes();
                //  for (int i = 0; i < bytes.Length; i++)
                //  {
                //      Console.Write(bytes[i]);
                //  }


                // byteList.AddRange(Encoding.ASCII.GetAddressBytes(EndPoint.Address.GetAddressBytes()));
                //byteList.AddRange(Encoding.ASCII.GetBytes(EndPoint));

                //{
                //    get { return EndPoint.Address.GetAddressBytes(); }
                //    set { endpoint.Address = new IPAddress(value); }
                }
                return byteList.ToArray();
            }

        }
    }

